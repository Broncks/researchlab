class Result_collector:
    cost_random = 0
    avg_cost_random = 0
    cost_greedy = 0
    avg_cost_greedy = 0
    cost_aco = 0
    avg_cost_aco = 0
